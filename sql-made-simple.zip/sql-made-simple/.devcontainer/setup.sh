#!/usr/bin/env bash
# Builds simplestore.db from the SQLite setup script and configures the sqlite3 shell for beginners.
set -euo pipefail
sudo apt-get update -qq
sudo apt-get install -y -qq sqlite3
rm -f simplestore.db
sqlite3 simplestore.db < database/sqlite/setup.sql
cat > "$HOME/.sqliterc" <<'RC'
.headers on
.mode box
PRAGMA foreign_keys = ON;
RC
echo "SimpleStore is ready: run  sqlite3 simplestore.db  then try  SELECT COUNT(*) FROM Customers;"
